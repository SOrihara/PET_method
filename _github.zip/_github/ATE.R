

rm(list = ls())

set.seed(20260501)


library(MASS)
library(PSweight)
library(doParallel)


ps <- function(aa) 1/(1+exp(-aa))

nn <- 2000
MM <- 2000

# Ma-Wang: number of subsamples for EACH trimming setting.
MW_B <- 1000


##### doParallel setting #####
n_cores <- max(1, parallel::detectCores() - 1)
cl <- parallel::makeCluster(n_cores)
doParallel::registerDoParallel(cl)
parallel::clusterSetRNGStream(cl, 20260501)


mw_ate <- function(AA, XX, YY, B = 1000L) {
  data <- data.frame(treat=AA, re78=YY, XX)
  ps_formula <- treat ~ XX1 + XX2 + XX3 + XX4 + XX5 + XX6
  n <- nrow(data)
  temp <- glm(ps_formula, data=data, family=binomial)
  data$pscore <- temp$fitted.values

  # Control-arm pilot: unchanged from the ATT code.
  temp <- lm(re78 ~ pscore, data=data[data$treat==0 & data$pscore >= 0.5, ])
  c1 <- temp$coefficients[1] + temp$coefficients[2]
  temp <- lm(I(re78^2) ~ pscore, data=data[data$treat==0 & data$pscore >= 0.5, ])
  c2 <- temp$coefficients[1] + temp$coefficients[2]
  bfactor <- c2 / c1^2

  # Treatment-arm pilot: evaluate the fitted lines at pscore=0.
  temp <- lm(re78 ~ pscore, data=data[data$treat==1 & data$pscore <= 0.5, ])
  c1L <- temp$coefficients[1]
  temp <- lm(I(re78^2) ~ pscore, data=data[data$treat==1 & data$pscore <= 0.5, ])
  c2L <- temp$coefficients[1]
  bfactorL <- c2L / c1L^2

  bandChoose <- function(a, b, X) {
    if (a == -1) {
      return (0)
    } else {
      optimize(function(x) abs(x^a * mean(X<=x) - b), lower=0, upper=1, maximum=FALSE)$minimum
    }
  }

  bnT <- c(-1, 1, 1.3, 2, 2.5, 3, 3.5)
  hnT <- c(0.2)
  repe <- B

  A <- BR <- HR <- BL <- HL <- S <- CL <- CR <- matrix(NA, nrow=length(bnT), ncol=length(hnT))
  for (i in 1:nrow(A)) for (j in 1:ncol(A)) {
    br <- 1-bandChoose(bnT[i], bfactor/(2*n), 1-data$pscore)
    hr <- 1-bandChoose(5, hnT[j]/n, 1-data$pscore)
    bl <- bandChoose(bnT[i], bfactorL/(2*n), data$pscore)
    hl <- bandChoose(5, hnT[j]/n, data$pscore)
    BR[i, j] <- br
    HR[i, j] <- hr
    BL[i, j] <- bl
    HL[i, j] <- hl

    tempR <- lm(re78 ~ pscore, data=data[data$treat==0 & data$pscore >= hr, ])$coefficients
    tempL <- lm(re78 ~ pscore, data=data[data$treat==1 & data$pscore <= hl, ])$coefficients

    z <- data$treat * data$re78 / data$pscore * (data$pscore >= bl) +
      (tempL[1] + tempL[2] * data$pscore) * (data$pscore <= bl) -
      (1-data$treat) * data$re78 / (1-data$pscore) * (data$pscore <= br) -
      (tempR[1] + tempR[2] * data$pscore) * (data$pscore >= br)
    A[i, j] <- mean(z)
    S[i, j] <- sd(z) / sqrt(n)

    nSS <- floor(n/log(n))
    tempA <- rep(NA, repe)
    tempS <- rep(NA, repe)
    for (ss in 1:repe) {
      indexSS <- sample(1:n, nSS, replace=FALSE)
      dataSS <- data[indexSS, ]
      temp <- glm(ps_formula, data=dataSS, family=binomial)
      dataSS$pscore <- temp$fitted.values

      br <- 1-bandChoose(bnT[i], bfactor/(2*nSS), 1-dataSS$pscore)
      hr <- 1-bandChoose(5, hnT[j]/nSS, 1-dataSS$pscore)
      bl <- bandChoose(bnT[i], bfactorL/(2*nSS), dataSS$pscore)
      hl <- bandChoose(5, hnT[j]/nSS, dataSS$pscore)

      if (sum(dataSS$treat==0 & dataSS$pscore >= hr) <= 2) {
        tempR <- c(0, 0)
      } else {
        tempR <- lm(re78 ~ pscore, data=dataSS[dataSS$treat==0 & dataSS$pscore >= hr, ])$coefficients
      }
      if (sum(dataSS$treat==1 & dataSS$pscore <= hl) <= 2) {
        tempL <- c(0, 0)
      } else {
        tempL <- lm(re78 ~ pscore, data=dataSS[dataSS$treat==1 & dataSS$pscore <= hl, ])$coefficients
      }

      zSS <- dataSS$treat * dataSS$re78 / dataSS$pscore * (dataSS$pscore >= bl) +
        (tempL[1] + tempL[2] * dataSS$pscore) * (dataSS$pscore <= bl) -
        (1-dataSS$treat) * dataSS$re78 / (1-dataSS$pscore) * (dataSS$pscore <= br) -
        (tempR[1] + tempR[2] * dataSS$pscore) * (dataSS$pscore >= br)
      tempA[ss] <- mean(zSS)
      tempS[ss] <- sd(zSS) / sqrt(nSS)
    }
    CL[i, j] <- A[i, j] - quantile((tempA - A[i, j]) / tempS, 0.975, na.rm=TRUE) * S[i, j]
    CR[i, j] <- A[i, j] - quantile((tempA - A[i, j]) / tempS, 0.025, na.rm=TRUE) * S[i, j]
  }
  list(A=A, S=S, CL=CL, CR=CR, BR=BR, HR=HR, BL=BL, HL=HL,
       bnT=bnT, hnT=hnT, bfactor=bfactor, bfactorL=bfactorL)
}


one_iter <- function(mm){
  ### DGM
  ##### Confounders #####
  Sigma <- matrix(0.5, nrow = 6, ncol = 6)
  diag(Sigma) <- 1
  
  VV <- mvrnorm(nn, mu = rep(0, 6), Sigma = Sigma)
  
  XX6 <- 1*(VV[,6] < 0)
  XX5 <- 1*(VV[,5] < 0)
  XX4 <- 1*(VV[,4] < 0)
  XX3 <- VV[,3]
  XX2 <- VV[,2]
  XX1 <- VV[,1]
  
  XX <- cbind(XX1, XX2, XX3, XX4, XX5, XX6)
  
  
  ##### Exposure #####
  # gamma <- 1    ### good
  gamma <- 3    ### poor
  
  
  if(gamma == 1)   alpha0 <- -1.2
  if(gamma == 3)   alpha0 <- -1.5
  
  
  AA_ln <- alpha0 + gamma*c(XX%*%c(0.15, 0.3, 0.3, -0.2, -0.25, -0.25))
  ee.s <- ps(AA_ln)
  AA <- mapply(rbinom, 1, 1, ee.s)
  # mean(ee.s)
  
  
  ##### Outcomes #####
  Delta <- 0.75
  # Delta <- 0.75 + 0.5*(XX[,1] + 1*(XX[,1]^2 - 1) + 0.5*XX[,2])
  
  # aa <- 1
  # sum(((ee.s*(1-ee.s))^aa)*Delta)/sum((ee.s*(1-ee.s))^aa)
  # plot(ee.s, Delta)
  
  
  ee <- rnorm(nn, sd = 1.5)
  YY <- Delta*AA + XX%*%c(-0.5, -0.5, -1.5, 0.8, 0.8, 1.0) + ee
  
  true <- 0.75
  
  
  ##### Create data frame #####
  DD <- data.frame(cbind(XX, AA, YY))
  names(DD) <- c("XX1", "XX2", "XX3", "XX4", "XX5", "XX6", "AA", "YY")
  
  
  
  #### Estimation ####
  # ee <- glm(AA ~ XX1 + XX2 + XX3 + XX4, family = binomial, data = DD)$fit
  # # ee <- ee.s
  # ee.v <- data.frame(cbind(1 - ee, ee))
  # names(ee.v) <- c("0", "1")
  
  
  ##### IPW #####
  kk_0 <- PSweight(ps.formula = AA ~ XX1 + XX2 + XX3 + XX4 + XX5 + XX6,
                   zname = "AA",
                   yname = "YY",
                   weight = "IPW",
                   data = DD)
  kekka_0 <- kk_0$muhat[2] - kk_0$muhat[1]
  se.i <- c(sqrt(c(1, -1)%*%kk_0$covmu%*%c(1, -1)))
  peci <- c(kekka_0 + qnorm(0.025)*se.i, kekka_0 + qnorm(0.975)*se.i)
  CI0 <- 0
  if(peci[1] < true & peci[2] > true) CI0 <- 1
  
  
  ##### ATO #####
  kk_1 <- PSweight(ps.formula = AA ~ XX1 + XX2 + XX3 + XX4 + XX5 + XX6,
                   zname = "AA",
                   yname = "YY",
                   weight = "overlap",
                   data = DD)
  kekka_1 <- kk_1$muhat[2] - kk_1$muhat[1]
  se.o <- c(sqrt(c(1, -1)%*%kk_1$covmu%*%c(1, -1)))
  peci <- c(kekka_1 + qnorm(0.025)*se.o, kekka_1 + qnorm(0.975)*se.o)
  CI1 <- 0
  if(peci[1] < true & peci[2] > true) CI1 <- 1


  ##### Crump #####
  kk_2.trim <- PStrim(ps.formula = AA ~ XX1 + XX2 + XX3 + XX4 + XX5 + XX6,
                      zname = "AA",
                      optimal = T,
                      data = DD)
  kk_2 <- PSweight(ps.formula = AA ~ XX1 + XX2 + XX3 + XX4 + XX5 + XX6,
                   zname = "AA",
                   yname = "YY",
                   weight = "IPW",
                   delta = kk_2.trim$delta,
                   data = kk_2.trim$data)
  kekka_2 <- kk_2$muhat[2] - kk_2$muhat[1]
  se.c <- c(sqrt(c(1, -1)%*%kk_2$covmu%*%c(1, -1)))
  peci <- c(kekka_2 + qnorm(0.025)*se.c, kekka_2 + qnorm(0.975)*se.c)
  CI2 <- 0
  if(peci[1] < true & peci[2] > true) CI2 <- 1
  
  
  ##### Yang's smooth weight
  smth <- function(AA, XX, YY){
    
    nn <- length(AA)
    
    ###### Propensity score ######
    XX.PS <- cbind(1, XX)
    ee <- glm(AA ~ -1 + XX.PS, family = binomial)$fit
    
    SS.PS <- XX.PS * (AA - ee)
    II.PS <- solve(t(SS.PS) %*% SS.PS/nn)
    
    ww.y1 <- pnorm(q = ee - kk_2.trim$delta, sd = 0.01)
    ww.y2 <- pnorm(q = (1 - kk_2.trim$delta) - ee, sd = 0.01)
    ww.dy1 <- dnorm(x = ee - kk_2.trim$delta, sd = 0.01)
    ww.dy2 <- dnorm(x = (1 - kk_2.trim$delta) - ee, sd = 0.01)
    ww.y <- ww.y1*ww.y2
    
    ###### Point estimates ######
    thet.y_1 <- sum(AA*ww.y*YY/ee)/sum(AA*ww.y/ee)
    thet.y_0 <- sum((1 - AA)*ww.y*YY/(1 - ee))/sum((1 - AA)*ww.y/(1 - ee))
    
    kk.y <- thet.y_1 - thet.y_0
    
    scor1.y <- (AA*ww.y/ee)*(YY - thet.y_1)/mean(AA*ww.y/ee)
    scor0.y <- ((1 - AA)*ww.y/(1 - ee))*(YY - thet.y_0)/mean((1 - AA)*ww.y/(1 - ee))
    
    
    WW.yd <- XX.PS * c((ww.dy1*ww.y2 - ww.y1*ww.dy2)*(AA*(1 - ee) + (1 - AA)*ee) - ww.y*(AA - ee)/(AA*ee + (1 - AA)*(1 - ee)))
    scor.PS1 <- c(t(WW.yd) %*% (AA * YY)/nn) - thet.y_1*c(t(WW.yd) %*% AA/nn)
    scor.PS0 <- c(t(WW.yd) %*% ((1 - AA) * YY)/nn) - thet.y_0*c(t(WW.yd) %*% (1 - AA)/nn)
    
    scor.PS <- c(SS.PS %*% c((scor.PS1 - scor.PS0) %*% II.PS/mean(ww.y)))
    
    
    ###### Asymptotic variance #######
    se.y <- sqrt(mean((scor1.y - scor0.y + scor.PS)^2)/nn)
    
    return(list(kk.y, se.y))
  }
  XX <- cbind(DD$XX1, DD$XX2, DD$XX3, DD$XX4, DD$XX5, DD$XX6)
  kk.y <- smth(DD$AA, XX, DD$YY)
  
  kekka_4 <- kk.y[[1]]
  peci <- c(kk.y[[1]] + qnorm(0.025)*kk.y[[2]], kk.y[[1]] + qnorm(0.975)*kk.y[[2]])
  CI4 <- 0
  if(peci[1] < true & peci[2] > true) CI4 <- 1
  
  
  
  ##### Proposed method (PET) #####
  polex <- function(aa, BB, AA, XX, YY){
    
    nn <- length(AA)
    
    ###### Propensity score ######
    XX.PS <- cbind(1, XX)
    ee <- glm(AA ~ -1 + XX.PS, family = binomial)$fit
    
    KK <- length(aa)
    kk_a <- thet_1 <- thet_0 <- rep(0, KK)
    scor1 <- scor0 <- scor.PS <- matrix(0, nrow = nn, ncol = KK)
    
    SS.PS <- XX.PS * (AA - ee)
    II.PS <- solve(t(SS.PS) %*% SS.PS/nn)
    
    ###### Projection matrix ######
    PB <- BB %*% solve(t(BB) %*% BB) %*% t(BB)
    alpha <- (1 - apply(PB, 2, sum))/c(t(rep(1, KK)) %*% (diag(KK) - PB) %*% rep(1, KK))
    
    
    for(ll in 1:KK){
      ww <- (ee*(1 - ee))^aa[ll]
      
      ###### Point estimates ######
      thet_1[ll] <- sum(AA*ww*YY/ee)/sum(AA*ww/ee)
      thet_0[ll] <- sum((1 - AA)*ww*YY/(1 - ee))/sum((1 - AA)*ww/(1 - ee))
      
      kk_a[ll] <- thet_1[ll] - thet_0[ll]
      
      scor1[, ll] <- (AA*ww/ee)*(YY - thet_1[ll])/mean(AA*ww/ee)
      scor0[, ll] <- ((1 - AA)*ww/(1 - ee))*(YY - thet_0[ll])/mean((1 - AA)*ww/(1 - ee))
      
      
      WW.d <- XX.PS * c(ww*(aa[ll]*(1 - 2*ee) - (AA - ee))/(AA*ee + (1 - AA)*(1 - ee)))
      scor.PS1 <- c(t(WW.d) %*% (AA * YY)/nn) - thet_1[ll]*c(t(WW.d) %*% AA/nn)
      scor.PS0 <- c(t(WW.d) %*% ((1 - AA) * YY)/nn) - thet_0[ll]*c(t(WW.d) %*% (1 - AA)/nn)
      
      scor.PS[, ll] <- c(SS.PS %*% c((scor.PS1 - scor.PS0) %*% II.PS/mean(ww)))
    }
    kk_ <- as.numeric(lm(kk_a ~ BB)$coef)
    
    
    ###### Asymptotic variance #######
    se <- sqrt(mean(c((scor1 - scor0 + scor.PS) %*% alpha)^2)/nn)
    
    return(list(kk_[1], se, kk_[-1], kk_a))
  }
  
  
  
  ###### 全探索 pattern ######
  bb_M <- 0.99
  bb_1.seq <- seq(0.44, 0.69, by = 0.05)
  kappa <- 10/12
  
  select_polex <- function(qq){
    
    XX <- cbind(DD$XX1, DD$XX2, DD$XX3, DD$XX4, DD$XX5, DD$XX6)
    kekka.bm <- matrix(0, nrow = length(bb_1.seq), ncol = 2)
    
    for(ll in 1:length(bb_1.seq)){
      bb_1 <- bb_1.seq[ll]
      
      aa1 <- seq(bb_1, bb_M, length.out = 50)
      BB1 <- poly(aa1, qq, raw = TRUE, simple = TRUE)
      
      ####### Evaluation #######
      kk <- polex(aa1, BB1, DD$AA, XX, DD$YY)
      
      kekka.bm[ll, ] <- c(bb_1, kk[[2]])
    }
    
    if(sum(kekka.bm[, 2] < sqrt(kappa)*se.i) == 0){
      bb_1 <- kekka.bm[length(bb_1.seq), 1]
    }else{
      ss <- which(kekka.bm[,2] < sqrt(kappa)*se.i)
      bb_1 <- kekka.bm[min(ss), 1]
    }
    
    aa1 <- seq(bb_1, bb_M, length.out = 50)
    BB1 <- poly(aa1, qq, raw = TRUE, simple = TRUE)
    kk <- polex(aa1, BB1, DD$AA, XX, DD$YY)
    
    return(list(kk[[1]], kk[[2]], bb_1))
    
  }
  kk_31 <- select_polex(1)
  kk_32 <- select_polex(2)
  kk_33 <- select_polex(3)
  kk_34 <- select_polex(4)
  
  se.p <- c(kk_31[[2]], kk_32[[2]], kk_33[[2]], kk_34[[2]])
  if(sum(se.p < sqrt(kappa)*se.i) == 0){
    kk_3 <- kk_31
  }else{
    ss <- max(which(se.p < sqrt(kappa)*se.i))
    if(ss == 1)   kk_3 <- kk_31
    if(ss == 2)   kk_3 <- kk_32
    if(ss == 3)   kk_3 <- kk_33
    if(ss == 4)   kk_3 <- kk_34
  }
  
  kekka_3 <- kk_3[[1]]
  kekka_31 <- kk_31[[1]]
  kekka_32 <- kk_32[[1]]
  kekka_33 <- kk_33[[1]]
  kekka_34 <- kk_34[[1]]
  
  
  peci <- c(kk_3[[1]] + qnorm(0.025)*kk_3[[2]], kk_3[[1]] + qnorm(0.975)*kk_3[[2]])
  CI3 <- 0
  if(peci[1] < true & peci[2] > true) CI3 <- 1
  
  peci <- c(kk_31[[1]] + qnorm(0.025)*kk_31[[2]], kk_31[[1]] + qnorm(0.975)*kk_31[[2]])
  CI31 <- 0
  if(peci[1] < true & peci[2] > true) CI31 <- 1
  
  peci <- c(kk_32[[1]] + qnorm(0.025)*kk_32[[2]], kk_32[[1]] + qnorm(0.975)*kk_32[[2]])
  CI32 <- 0
  if(peci[1] < true & peci[2] > true) CI32 <- 1
  
  peci <- c(kk_33[[1]] + qnorm(0.025)*kk_33[[2]], kk_33[[1]] + qnorm(0.975)*kk_33[[2]])
  CI33 <- 0
  if(peci[1] < true & peci[2] > true) CI33 <- 1

  peci <- c(kk_34[[1]] + qnorm(0.025)*kk_34[[2]], kk_34[[1]] + qnorm(0.975)*kk_34[[2]])
  CI34 <- 0
  if(peci[1] < true & peci[2] > true) CI34 <- 1
  
  
  ###### Plot ######
  # plot(aa, kk_a)
  # plot(aa, aa^2); cor(aa, aa^2)
  
  #### Counter ####
  if(mm %% 200 == 0) print(mm)
  
  #### Ma-Wang: same generated data; original PET random sequence retained ####
  mw_rng <- get(".Random.seed", envir = .GlobalEnv)
  mw <- mw_ate(DD$AA, as.matrix(DD[, paste0("XX", 1:6)]), DD$YY, B = MW_B)
  assign(".Random.seed", mw_rng, envir = .GlobalEnv)
  mw_suffix <- c("no_trim", "1", "1_3", "2", "2_5", "3", "3_5")
  mw_values <- c(
    setNames(as.vector(mw$A), paste0("kekka_mw_", mw_suffix)),
    setNames(as.vector(mw$S), paste0("se.mw_", mw_suffix)),
    setNames(as.vector(1 * (mw$CL < true & mw$CR > true)), paste0("CImw_", mw_suffix)),
    setNames(as.vector(mw$CL), paste0("CI.mw.lower_", mw_suffix)),
    setNames(as.vector(mw$CR), paste0("CI.mw.upper_", mw_suffix)))

  c(kekka_0 = kekka_0, kekka_1 = kekka_1, kekka_2 = kekka_2, kekka_3 = kekka_3, kekka_4 = kekka_4,
    kekka_31 = kekka_31, kekka_32 = kekka_32, kekka_33 = kekka_33, kekka_34 = kekka_34,
    se.i = se.i, se.o = se.o, se.c = se.c, se.p = kk_3[[2]], se.y = kk.y[[2]], 
    se.p1 = kk_31[[2]], se.p2 = kk_32[[2]], se.p3 = kk_33[[2]], se.p4 = kk_34[[2]], 
    CI0 = CI0, CI1 = CI1, CI2 = CI2, CI3 = CI3, CI4 = CI4,
    CI31 = CI31, CI32 = CI32, CI33 = CI33, CI34 = CI34,
    mw_values)
}

res <- foreach::foreach(mm = 1:MM,
                        .combine = rbind,
                        .inorder = TRUE,
                        .packages = c("MASS", "PSweight"),
                        .export = c("nn", "ps", "one_iter", "mw_ate", "MW_B")) %dopar% {
  one_iter(mm)
}

parallel::stopCluster(cl)

kekka_0 <- res[, "kekka_0.1"]
kekka_1 <- res[, "kekka_1.1"]
kekka_2 <- res[, "kekka_2.1"]
kekka_4 <- res[, "kekka_4"]
kekka_3 <- res[, "kekka_3"]
kekka_31 <- res[, "kekka_31"]
kekka_32 <- res[, "kekka_32"]
kekka_33 <- res[, "kekka_33"]
kekka_34 <- res[, "kekka_34"]

se0 <- res[, "se.i"]
se1 <- res[, "se.o"]
se2 <- res[, "se.c"]
se4 <- res[, "se.y"]
se3 <- res[, "se.p"]
se31 <- res[, "se.p1"]
se32 <- res[, "se.p2"]
se33 <- res[, "se.p3"]
se34 <- res[, "se.p4"]

CI0 <- res[, "CI0"]
CI1 <- res[, "CI1"]
CI2 <- res[, "CI2"]
CI4 <- res[, "CI4"]
CI3 <- res[, "CI3"]
CI31 <- res[, "CI31"]
CI32 <- res[, "CI32"]
CI33 <- res[, "CI33"]
CI34 <- res[, "CI34"]

#### Main results ####
kekka <- data.frame(cbind(kekka_0, kekka_1, kekka_2, kekka_4, kekka_3, kekka_31, kekka_32, kekka_33, kekka_34))
kekka.se <- data.frame(cbind(se0, se1, se2, se4, se3, se31, se32, se33, se34))
kekka.CI <- data.frame(cbind(CI0, CI1, CI2, CI4, CI3, CI31, CI32, CI33, CI34))

names(kekka) <- names(kekka.CI) <- c("IPW", "ATO", "Crump\n(alpha:optimal)", "Yang\n(alpha:optimal)",
                                     "Proposed (select)",
                                     "Proposed (q = 1)", "Proposed (q = 2)","Proposed (q = 3)", "Proposed (q = 4)")

#### Ma-Wang results: append seven settings after the original nine methods ####
mw_suffix <- c("no_trim", "1", "1_3", "2", "2_5", "3", "3_5")
mw_labels <- paste0("Ma-Wang (bnT=", c(-1, 1, 1.3, 2, 2.5, 3, 3.5), ")")
kekka_mw <- res[, paste0("kekka_mw_", mw_suffix), drop = FALSE]
se_mw <- res[, paste0("se.mw_", mw_suffix), drop = FALSE]
CI_mw <- res[, paste0("CImw_", mw_suffix), drop = FALSE]
ci_mw_lower <- res[, paste0("CI.mw.lower_", mw_suffix), drop = FALSE]
ci_mw_upper <- res[, paste0("CI.mw.upper_", mw_suffix), drop = FALSE]
colnames(kekka_mw) <- colnames(se_mw) <- colnames(CI_mw) <-
  colnames(ci_mw_lower) <- colnames(ci_mw_upper) <- mw_labels
kekka <- cbind(kekka, kekka_mw)
kekka.se <- cbind(kekka.se, se_mw)
kekka.CI <- cbind(kekka.CI, CI_mw)



true <- 0.75


boxplot(kekka)
abline(h = true, col = "red", lty = 2, lwd = 3)

apply(kekka, 2, sd)
apply(kekka.se, 2, mean)
apply(kekka, 2, mean) - true

mean(CI0); mean(CI1); mean(CI2); mean(CI4)
mean(CI3); mean(CI31); mean(CI32); mean(CI33); mean(CI34)
colMeans(CI_mw)

sqrt(apply(kekka, 2, var) + (apply(kekka, 2, mean) - true)^2)


#### Additional results ####
# boxplot(kekka_a)
# summary(kekka_a)
# boxplot(kekka_t)

