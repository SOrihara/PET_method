

rm(list = ls())

set.seed(20260501)


library(MASS)
library(PSweight)
library(doParallel)


ps <- function(aa) 1/(1+exp(-aa))

nn <- 2000
MM <- 1000


##### doParallel setting #####
n_cores <- max(1, parallel::detectCores() - 2)
cl <- parallel::makeCluster(n_cores)
doParallel::registerDoParallel(cl)
parallel::clusterSetRNGStream(cl, 20260501)


one_iter <- function(mm){
  ### DGM
  ##### Confounders #####
  Sigma <- matrix(0.5, nrow = 6, ncol = 6)
  diag(Sigma) <- 1
  
  VV <- mvrnorm(nn, mu = rep(0, 6), Sigma = Sigma)
  
  XX6 <- 1*(VV[,6] < 0)
  XX5 <- 1*(VV[,5] < 0)
  XX4 <- 1*(VV[,4] < 0)
  XX3 <- VV[,3]
  XX2 <- VV[,2]
  XX1 <- VV[,1]
  
  XX <- cbind(XX1, XX2, XX3, XX4, XX5, XX6)
  
  
  ##### Exposure #####
  # gamma <- 1    ### good
  gamma <- 3    ### poor
  
  
  if(gamma == 1)   alpha0 <- -1.2
  if(gamma == 3)   alpha0 <- -1.5
  
  
  AA_ln <- alpha0 + gamma*c(XX%*%c(0.15, 0.3, 0.3, -0.2, -0.25, -0.25))
  ee.s <- ps(AA_ln)
  AA <- mapply(rbinom, 1, 1, ee.s)
  # mean(ee.s)
  
  
  ##### Outcomes #####
  Delta <- 0.75 + 0.5*(XX[,1] + 1*(XX[,1]^2 - 1) + 0.5*XX[,2])
  
  # aa <- 1
  # sum(((ee.s*(1-ee.s))^aa)*Delta)/sum((ee.s*(1-ee.s))^aa)
  # plot(ee.s, Delta)
  
  
  ee <- rnorm(nn, sd = 1.5)
  YY <- Delta*AA + XX%*%c(-0.5, -0.5, -1.5, 0.8, 0.8, 1.0) + ee
  
  true <- 0.75
  
  
  ##### Create data frame #####
  DD <- data.frame(cbind(XX, AA, YY))
  names(DD) <- c("XX1", "XX2", "XX3", "XX4", "XX5", "XX6", "AA", "YY")
  
  
  
  #### Estimation ####
  ee <- glm(AA ~ XX1 + XX2 + XX3 + XX4 + XX5 + XX6, family = binomial, data = DD)$fit
  # ee <- ee.s
  ee.v <- data.frame(cbind(1 - ee, ee))
  names(ee.v) <- c("0", "1")
  
  
  ###### Outcome regression ######
  XX.mm <- data.frame(cbind(AA, XX))
  names(XX.mm) <- c("AA", "XX1", "XX2", "XX3", "XX4", "XX5", "XX6")
  XX.m1 <- data.frame(cbind(1, 1, XX))
  XX.m0 <- data.frame(cbind(1, 0, XX))
  names(XX.m1) <- names(XX.m0) <- c("", "AA", "XX1", "XX2", "XX3", "XX4", "XX5", "XX6")
  mm.AX <- lm(YY ~ AA + XX1 + XX2 + XX3 + XX4 + XX5 + XX6 + AA*XX1 + AA*XX2 + AA*I(XX1^2), data = XX.mm)
  mm.1X <- predict(mm.AX, XX.m1)
  mm.0X <- predict(mm.AX, XX.m0)
  oo.v <- data.frame(mm.0X, mm.1X)
  names(oo.v) <- c("0", "1")
  
  
  ##### IPW #####
  kk_0 <- PSweight(ps.estimate = ee.v,
                   out.estimate = oo.v,
                   zname = "AA",
                   yname = "YY",
                   weight = "IPW",
                   augmentation = T,
                   data = DD)
  kekka_0 <- kk_0$muhat[2] - kk_0$muhat[1]
  se.i <- c(sqrt(c(1, -1)%*%kk_0$covmu%*%c(1, -1)))
  peci <- c(kekka_0 + qnorm(0.025)*se.i, kekka_0 + qnorm(0.975)*se.i)
  CI0 <- 0
  if(peci[1] < true & peci[2] > true) CI0 <- 1
  
  
  ##### ATO #####
  kk_1 <- PSweight(ps.estimate = ee.v,
                   out.estimate = oo.v,
                   zname = "AA",
                   yname = "YY",
                   weight = "overlap",
                   augmentation = T,
                   data = DD)
  kekka_1 <- kk_1$muhat[2] - kk_1$muhat[1]
  se.o <- c(sqrt(c(1, -1)%*%kk_1$covmu%*%c(1, -1)))
  peci <- c(kekka_1 + qnorm(0.025)*se.o, kekka_1 + qnorm(0.975)*se.o)
  CI1 <- 0
  if(peci[1] < true & peci[2] > true) CI1 <- 1
  
  
  ##### Crump #####
  kk_2.trim <- PStrim(ps.estimate = ee.v,
                      out.estimate = oo.v,
                      zname = "AA",
                      optimal = T,
                      data = DD)
  kk_2 <- PSweight(ps.estimate = kk_2.trim$ps.estimate,
                   out.estimate = kk_2.trim$out.estimate,
                   zname = "AA",
                   yname = "YY",
                   weight = "IPW",
                   augmentation = T,
                   delta = kk_2.trim$delta,
                   data = kk_2.trim$data)
  kekka_2 <- kk_2$muhat[2] - kk_2$muhat[1]
  se.c <- c(sqrt(c(1, -1)%*%kk_2$covmu%*%c(1, -1)))
  peci <- c(kekka_2 + qnorm(0.025)*se.c, kekka_2 + qnorm(0.975)*se.c)
  CI2 <- 0
  if(peci[1] < true & peci[2] > true) CI2 <- 1
  
  
  ##### Yang's smooth weight
  smth <- function(AA, XX, YY){
    
    nn <- length(AA)
    
    ###### Propensity score ######
    XX.PS <- cbind(1, XX)
    ee <- glm(AA ~ -1 + XX.PS, family = binomial)$fit
    
    ###### Outcome regression ######
    XX.mm <- data.frame(cbind(AA, XX))
    names(XX.mm) <- c("AA", "XX1", "XX2", "XX3", "XX4", "XX5", "XX6")
    XX.m1 <- data.frame(cbind(1, 1, XX))
    XX.m0 <- data.frame(cbind(1, 0, XX))
    names(XX.m1) <- names(XX.m0) <- c("", "AA", "XX1", "XX2", "XX3", "XX4", "XX5", "XX6")
    mm.AX <- lm(YY ~ AA + XX1 + XX2 + XX3 + XX4 + XX5 + XX6 + AA*XX1 + AA*XX2 + AA*I(XX1^2), data = XX.mm)
    mm.1X <- predict(mm.AX, XX.m1)
    mm.0X <- predict(mm.AX, XX.m0)
    
    ww.y <- pnorm(q = ee - kk_2.trim$delta, sd = 0.01)*pnorm(q = (1 - kk_2.trim$delta) - ee, sd = 0.01)
    
    ###### Point estimates ######
    tau.y <- c(mean(ww.y*((AA/ee - (1 - AA)/(1 - ee))*YY + (1 - AA/ee)*mm.1X - (1 - (1 - AA)/(1 - ee))*mm.0X))/mean(ww.y))
    
    ###### EIF ######
    phi.y <- c(ww.y*((AA/ee - (1 - AA)/(1 - ee))*YY + (1 - AA/ee)*mm.1X - (1 - (1 - AA)/(1 - ee))*mm.0X - tau.y)/mean(ww.y))
    
    ###### Asymptotic variance #######
    se.y <- sqrt(mean(phi.y^2)/nn)
    
    return(list(tau.y, se.y))
  }
  XX <- cbind(DD$XX1, DD$XX2, DD$XX3, DD$XX4, DD$XX5, DD$XX6)
  kk.y <- smth(DD$AA, XX, DD$YY)
  
  kekka_4 <- kk.y[[1]]
  peci <- c(kk.y[[1]] + qnorm(0.025)*kk.y[[2]], kk.y[[1]] + qnorm(0.975)*kk.y[[2]])
  CI4 <- 0
  if(peci[1] < true & peci[2] > true) CI4 <- 1
  
  
  
  ##### Proposed method (PET) #####
  polex <- function(aa, BB, AA, XX, YY){
    
    nn <- length(AA)
    
    ###### Propensity score ######
    XX.PS <- cbind(1, XX)
    ee <- glm(AA ~ XX.PS, family = binomial)$fit
    
    ###### Outcome regression ######
    XX.mm <- data.frame(cbind(AA, XX))
    names(XX.mm) <- c("AA", "XX1", "XX2", "XX3", "XX4", "XX5", "XX6")
    XX.m1 <- data.frame(cbind(1, 1, XX))
    XX.m0 <- data.frame(cbind(1, 0, XX))
    names(XX.m1) <- names(XX.m0) <- c("", "AA", "XX1", "XX2", "XX3", "XX4", "XX5", "XX6")
    mm.AX <- lm(YY ~ AA + XX1 + XX2 + XX3 + XX4 + XX5 + XX6 + AA*XX1 + AA*XX2 + AA*I(XX1^2), data = XX.mm)
    mm.1X <- predict(mm.AX, XX.m1)
    mm.0X <- predict(mm.AX, XX.m0)
    
    KK <- length(aa)
    tau <- rep(0, KK)
    phi <- matrix(0, nrow = nn, ncol = KK)
    
    ###### Projection matrix ######
    PB <- BB %*% solve(t(BB) %*% BB) %*% t(BB)
    alpha <- (1 - apply(PB, 2, sum))/c(t(rep(1, KK)) %*% (diag(KK) - PB) %*% rep(1, KK))
    
    for(ll in 1:KK){
      ww <- (ee*(1 - ee))^aa[ll]
      WW <- ww/(AA*ee + (1 - AA)*(1 - ee))
      
      ###### Point estimates ######
      tau[ll] <- c(mean(ww*((AA/ee - (1 - AA)/(1 - ee))*YY + (1 - AA/ee)*mm.1X - (1 - (1 - AA)/(1 - ee))*mm.0X))/mean(ww))
      # tau[ll] <- c(mean(ww*(mm.1X - mm.0X)/mean(ww) + WW*AA*(YY - mm.1X)/mean(WW*AA) - WW*(1 - AA)*(YY - mm.0X)/mean(WW*(1 - AA))))
      
      ###### EIF ######
      phi[, ll] <- c(ww*((AA/ee - (1 - AA)/(1 - ee))*YY + (1 - AA/ee)*mm.1X - (1 - (1 - AA)/(1 - ee))*mm.0X - tau[ll])/mean(ww))
      # phi[, ll] <- c(ww*(mm.1X - mm.0X)/mean(ww) + WW*AA*(YY - mm.1X)/mean(WW*AA) - WW*(1 - AA)*(YY - mm.0X)/mean(WW*(1 - AA)) - tau[ll])
    }
    tau_DR <- c(tau %*% alpha)
    phi_EIF <- c(phi %*% alpha)
    
    ###### Asymptotic variance #######
    se <- sqrt(mean(phi_EIF^2)/nn)
    
    return(list(tau_DR, se))
  }
  
  
  
  ###### 全探索 pattern ######
  bb_M <- 0.99
  bb_1.seq <- seq(0.44, 0.69, by = 0.05)
  
  select_polex <- function(qq){
    
    XX <- cbind(DD$XX1, DD$XX2, DD$XX3, DD$XX4, DD$XX5, DD$XX6)
    kekka.bm <- matrix(0, nrow = length(bb_1.seq), ncol = 2)
    
    for(ll in 1:length(bb_1.seq)){
      bb_1 <- bb_1.seq[ll]
      
      aa1 <- seq(bb_1, bb_M, length.out = 50)
      BB1 <- poly(aa1, qq, raw = TRUE, simple = TRUE)
      
      ####### Evaluation #######
      kk <- polex(aa1, BB1, DD$AA, XX, DD$YY)
      
      kekka.bm[ll, ] <- c(bb_1, kk[[2]])
    }
    
    if(sum(kekka.bm[, 2] < 1*se.i) == 0){
      bb_1 <- kekka.bm[length(bb_1.seq), 1]
    }else{
      ss <- which(kekka.bm[,2] < 1*se.i)
      bb_1 <- kekka.bm[min(ss), 1]
    }
    
    aa1 <- seq(bb_1, bb_M, length.out = 50)
    BB1 <- poly(aa1, qq, raw = TRUE, simple = TRUE)
    kk <- polex(aa1, BB1, DD$AA, XX, DD$YY)
    
    return(list(kk[[1]], kk[[2]], bb_1))
    
  }
  kk_31 <- select_polex(1)
  kk_32 <- select_polex(2)
  kk_33 <- select_polex(3)
  kk_34 <- select_polex(4)
  
  se.p <- c(kk_31[[2]], kk_32[[2]], kk_33[[2]], kk_34[[2]])
  if(sum(se.p < 1*se.i) == 0){
    kk_3 <- kk_31
  }else{
    ss <- max(which(se.p < 1*se.i))
    if(ss == 1)   kk_3 <- kk_31
    if(ss == 2)   kk_3 <- kk_32
    if(ss == 3)   kk_3 <- kk_33
    if(ss == 4)   kk_3 <- kk_34
  }
  
  kekka_3 <- kk_3[[1]]
  kekka_31 <- kk_31[[1]]
  kekka_32 <- kk_32[[1]]
  kekka_33 <- kk_33[[1]]
  kekka_34 <- kk_34[[1]]
  
  
  peci <- c(kk_3[[1]] + qnorm(0.025)*kk_3[[2]], kk_3[[1]] + qnorm(0.975)*kk_3[[2]])
  CI3 <- 0
  if(peci[1] < true & peci[2] > true) CI3 <- 1
  
  peci <- c(kk_31[[1]] + qnorm(0.025)*kk_31[[2]], kk_31[[1]] + qnorm(0.975)*kk_31[[2]])
  CI31 <- 0
  if(peci[1] < true & peci[2] > true) CI31 <- 1
  
  peci <- c(kk_32[[1]] + qnorm(0.025)*kk_32[[2]], kk_32[[1]] + qnorm(0.975)*kk_32[[2]])
  CI32 <- 0
  if(peci[1] < true & peci[2] > true) CI32 <- 1
  
  peci <- c(kk_33[[1]] + qnorm(0.025)*kk_33[[2]], kk_33[[1]] + qnorm(0.975)*kk_33[[2]])
  CI33 <- 0
  if(peci[1] < true & peci[2] > true) CI33 <- 1

  peci <- c(kk_34[[1]] + qnorm(0.025)*kk_34[[2]], kk_34[[1]] + qnorm(0.975)*kk_34[[2]])
  CI34 <- 0
  if(peci[1] < true & peci[2] > true) CI34 <- 1
  
  
  ###### Plot ######
  # plot(aa, kk_a)
  # plot(aa, aa^2); cor(aa, aa^2)
  
  #### Counter ####
  if(mm %% 200 == 0) print(mm)
  
  c(kekka_0 = kekka_0, kekka_1 = kekka_1, kekka_2 = kekka_2, kekka_3 = kekka_3, kekka_4 = kekka_4,
    kekka_31 = kekka_31, kekka_32 = kekka_32, kekka_33 = kekka_33, kekka_34 = kekka_34,
    se.i = se.i, se.o = se.o, se.c = se.c, se.p = kk_3[[2]], se.y = kk.y[[2]], 
    se.p1 = kk_31[[2]], se.p2 = kk_32[[2]], se.p3 = kk_33[[2]], se.p4 = kk_34[[2]], 
    CI0 = CI0, CI1 = CI1, CI2 = CI2, CI3 = CI3, CI4 = CI4,
    CI31 = CI31, CI32 = CI32, CI33 = CI33, CI34 = CI34)
}

res <- foreach::foreach(mm = 1:MM,
                        .combine = rbind,
                        .inorder = TRUE,
                        .packages = c("MASS", "PSweight"),
                        .export = c("nn", "ps", "one_iter")) %dopar% {
                          one_iter(mm)
                        }

parallel::stopCluster(cl)

kekka_0 <- res[, "kekka_0.1"]
kekka_1 <- res[, "kekka_1.1"]
kekka_2 <- res[, "kekka_2.1"]
kekka_4 <- res[, "kekka_4"]
kekka_3 <- res[, "kekka_3"]
kekka_31 <- res[, "kekka_31"]
kekka_32 <- res[, "kekka_32"]
kekka_33 <- res[, "kekka_33"]
kekka_34 <- res[, "kekka_34"]

se0 <- res[, "se.i"]
se1 <- res[, "se.o"]
se2 <- res[, "se.c"]
se4 <- res[, "se.y"]
se3 <- res[, "se.p"]
se31 <- res[, "se.p1"]
se32 <- res[, "se.p2"]
se33 <- res[, "se.p3"]
se34 <- res[, "se.p4"]

CI0 <- res[, "CI0"]
CI1 <- res[, "CI1"]
CI2 <- res[, "CI2"]
CI4 <- res[, "CI4"]
CI3 <- res[, "CI3"]
CI31 <- res[, "CI31"]
CI32 <- res[, "CI32"]
CI33 <- res[, "CI33"]
CI34 <- res[, "CI34"]

#### Main results ####
kekka <- data.frame(cbind(kekka_0, kekka_1, kekka_2, kekka_4, kekka_3, kekka_31, kekka_32, kekka_33, kekka_34))
kekka.se <- data.frame(cbind(se0, se1, se2, se4, se3, se31, se32, se33, se34))
kekka.CI <- data.frame(cbind(CI0, CI1, CI2, CI4, CI3, CI31, CI32, CI33, CI34))

names(kekka) <- names(kekka.CI) <- c("IPW", "ATO", "Crump\n(alpha:optimal)", "Yang\n(alpha:optimal)",
                                     "Proposed (select)",
                                     "Proposed (q = 1)", "Proposed (q = 2)","Proposed (q = 3)", "Proposed (q = 4)")


true <- 0.75


boxplot(kekka)
abline(h = true, col = "red", lty = 2, lwd = 3)

apply(kekka, 2, sd)
apply(kekka.se, 2, mean)
apply(kekka, 2, mean) - true

mean(CI0); mean(CI1); mean(CI2); mean(CI4)
mean(CI3); mean(CI31); mean(CI32); mean(CI33); mean(CI34)

sqrt(apply(kekka, 2, var) + (apply(kekka, 2, mean) - true)^2)


#### Additional results ####
# boxplot(kekka_a)
# summary(kekka_a)
# boxplot(kekka_t)

